﻿//Welcome use PrintDialog, here is an example below
//PrintDialog have some other great functions
//Like PaperHelper, PrinterHelper and DocumentMaker
//You can find them in namespace which named by thier name
//They can help you to make and print some good documents
//Copyright © Jet Wang 2020

using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Documents;

namespace PrintDialogExample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TestButtonClick(object sender, RoutedEventArgs e)
        {
            //Create a new document ( A document contains many pages )
            //PrintDialog can only print and preview a FixedDocument
            //Here are some codes to make a document, if you already know how to do it, you can skip it or put your document instead
            FixedDocument fixedDocument = new FixedDocument();
            fixedDocument.DocumentPaginator.PageSize = PaperHelper.PaperHelper.GetPaperSize(System.Printing.PageMediaSizeName.ISOA4); //Use PrintHelper to set A4 page size

            //Create a new page and set its size
            //Page's size may equals document's size
            FixedPage fixedPage = new FixedPage
            {
                Width = fixedDocument.DocumentPaginator.PageSize.Width,
                Height = fixedDocument.DocumentPaginator.PageSize.Height
            };

            //Create a StackPanel and make it cover entire page
            //FixedPage can contains any UIElement. But VerticalAlignment="Stretch" or HorizontalAlignment="Stretch" doesn't work, so you need calculate its size to make it cover page
            StackPanel stackPanel = new StackPanel()
            {
                Orientation = Orientation.Vertical,
                Width = fixedDocument.DocumentPaginator.PageSize.Width - 120, //Width = Page width - (Left margin + Right margin)
                Height = fixedDocument.DocumentPaginator.PageSize.Height - 120 //Height = Page height - (Top margin + Bottom margin)
            };

            //Put some elements into StackPanel ( As same way as normal and it may have styles, but triggers and animations don't work )
            stackPanel.Children.Add(new TextBlock { Text = "These are some regular text.", Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBlock { Text = "These are some bold text.", FontWeight = FontWeights.Bold, Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBlock { Text = "These are some italic text.", FontStyle = FontStyles.Italic, Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBlock { Text = "These are some different color text.", Foreground = Brushes.Red, Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBlock { Text = "This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph. This is a very long paragraph.",
                MaxWidth = stackPanel.Width, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 5, 0, 5) }); //You need to set MaxWidth and TextWrapping properties to make a multi-line paragraph.
            stackPanel.Children.Add(new Button { Content = "This is a button.", Margin = new Thickness(0, 5, 0, 5), Width = 250, Height = 30, VerticalContentAlignment = VerticalAlignment.Center });
            stackPanel.Children.Add(new Button { Content = "This is a button with different color.", BorderBrush = Brushes.Black, Background = Brushes.DarkGray, Foreground = Brushes.White, Width = 250, Height = 30, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 5, 0, 5) });
            stackPanel.Children.Add(new TextBox { Text = "This is a textbox, but you can't type text in FixedDocument.", Margin = new Thickness(0, 5, 0, 5), Width = 550, Height = 30, VerticalContentAlignment = VerticalAlignment.Center });

            //Set element's margin ( You can set top, bottom, left and right. But usually, we only set top and left )
            //FixedPage doesn't have Margin or Padding property, so if you want a inner margin, you can use a container control ( Like Grid, StackPanel, WrapPanel, etc ) to contains any element in the page and set its margin.
            //You can use Margin property to make same thing, but the best way is use FixedPage.SetTop, FixedPage.SetLeft, FixedPage.SetBottom and FixedPage.SetRight function
            FixedPage.SetTop(stackPanel, 60); //top margin is 60 pixel
            FixedPage.SetLeft(stackPanel, 60); //left margin is 60 pixel

            //Add element into page
            //You can add many elements into page, but at here we only add one
            fixedPage.Children.Add(stackPanel);

            //Add page into document
            //You can't just add FixedPage into FixedDocument, you need use PageContent to contains FixedPage
            fixedDocument.Pages.Add(new PageContent { Child = fixedPage });

            //Initialize PrintDialog and set its properties
            PrintDialog.PrintDialog printDialog = new PrintDialog.PrintDialog
            {
                Icon = null, //Set PrintDialog's icon ( Null means use system default icon )
                PrintDocument = fixedDocument //Set document that need to print
            };

            //Show PrintDialog
            //If there is no internet, it need a longer time to find printers
            //But after first time, it will need a shorter time
            if (printDialog.ShowDialog() == true)
            {
                //When Print button clicked, document printed and window closed
                //You can put your own codes at here instead
                MessageBox.Show("Document printed.", "PrintDialog", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK);
            }
            else
            {
                //When Cancel button clicked and window closed
                //You can put your own codes at here instead
                MessageBox.Show("Print job canceled.", "PrintDialog", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK);
            }
        }
    }
}
