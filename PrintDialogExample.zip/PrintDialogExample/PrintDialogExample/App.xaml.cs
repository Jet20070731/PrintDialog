﻿using System.Windows;

namespace PrintDialogExample
{
    public partial class App : Application
    {

    }
}
